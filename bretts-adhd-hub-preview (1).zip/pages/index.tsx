export default function Home() {
  return (
    <div className="p-10 text-center text-2xl">
      🧠 Brett’s ADHD Hub — Preview Mode!
      <p className="mt-4">Try going to /tip/impulse-hack-1</p>
    </div>
  );
}
