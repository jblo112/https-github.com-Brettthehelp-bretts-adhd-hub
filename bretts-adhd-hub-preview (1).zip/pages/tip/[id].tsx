import { useRouter } from 'next/router';
import { motion } from 'framer-motion';
import Link from 'next/link';

const tips = {
  "impulse-hack-1": {
    title: "📦 Impulse Hack #1",
    content: "Boost your mood with simple delay tricks and grounding techniques.",
    tags: ["impulse", "mood"]
  }
};

export default function TipPage() {
  const router = useRouter();
  const { id } = router.query;
  const tip = tips[id];

  if (!tip) return <div className="text-center p-10">Loading...</div>;

  return (
    <motion.div className="p-10">
      <h1>{tip.title}</h1>
      <p>{tip.content}</p>
      <div>{tip.tags.map((tag, i) => <span key={i}>#{tag} </span>)}</div>
      <Link href="/"><a>← Back to Tips</a></Link>
    </motion.div>
  );
}
